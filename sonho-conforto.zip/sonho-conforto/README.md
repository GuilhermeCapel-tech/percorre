# Sonho & Conforto

Site estático (HTML, CSS e JavaScript puros), responsivo, com vídeos e imagens.

## Estrutura

```
index.html
img/     fotos e logo (.jpg)
vid/     vídeos da equipe (.mp4)
audio/   coloque aqui trilha.mp3 (opcional)
```

## Antes de publicar

- **WhatsApp:** no final do `index.html`, preencha `var WHATSAPP = "";` com o número só com dígitos, por exemplo `5519999999999`.
- **Música:** salve a música como `audio/trilha.mp3`. O player só aparece se o arquivo existir.

## Publicar na Vercel

1. Crie um repositório novo no GitHub e envie o conteúdo desta pasta (Add file > Upload files).
2. Na Vercel: Add New > Project > escolha o repositório > Deploy. Não precisa configurar nada (Framework Preset: Other).
